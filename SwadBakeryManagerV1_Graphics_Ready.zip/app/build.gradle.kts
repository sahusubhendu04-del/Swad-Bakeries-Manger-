plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.swadbakery.manager"; compileSdk = 35
    defaultConfig { applicationId = "com.swadbakery.manager"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
