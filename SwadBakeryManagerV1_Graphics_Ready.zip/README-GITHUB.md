# Swad Bakery Manager V1

Android bakery management app prototype for Maa Bake House / Swad Bakeries.

## Build APK with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this folder (not the ZIP file itself).
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Swad Bakery APK**.
6. If it hasn't run automatically, choose **Run workflow**.
7. After it succeeds, open the workflow run and download the **Swad-Bakery-Manager-V1** artifact.
8. Extract the artifact and install `app-debug.apk` on Android.

This is a debug APK for testing, not a Play Store release build.
