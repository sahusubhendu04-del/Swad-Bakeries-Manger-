package com.swadbakery.manager

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup
import android.content.Context

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("swad", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(250,247,242))
        }
        val bar = TextView(this).apply {
            text = title; textSize = 24f; setTextColor(Color.rgb(105,55,20))
            gravity = Gravity.CENTER_VERTICAL; setPadding(0,0,0,18)
        }
        root.addView(bar)
        setContentView(root)
        return root
    }

    private fun btn(text:String, action:()->Unit) = Button(this).apply {
        this.text=text; setOnClickListener{action()}; isAllCaps=false
    }

    private fun showDashboard() {
        base("Swad Bakery Manager")
        val hero = ImageView(this).apply {
            setImageResource(com.swadbakery.manager.R.drawable.bakery_header)
            scaleType = ImageView.ScaleType.CENTER_CROP
            adjustViewBounds = true
            contentDescription = "Swad Bakeries bread graphic"
        }
        root.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 300))
        val info = TextView(this).apply {
            text = "Maa Bake House • Swad Bakeries\nToday’s business at a glance"
            textSize=17f; gravity = Gravity.CENTER; setPadding(0,18,0,18)
            setTextColor(Color.rgb(105,55,20))
        }
        root.addView(info)
        root.addView(btn("🏭 Production") { production() })
        root.addView(btn("🧾 Sales") { sales() })
        root.addView(btn("👥 Customers") { customers() })
        root.addView(btn("📦 Raw Material Stock") { stock() })
        root.addView(btn("📊 Reports") { reports() })
    }

    private fun production() {
        base("Production")
        val products=arrayOf("Bread","Bun","Rusk","Cookies","Petis","Petis Roll","Pastry","Birthday Cake")
        val spinner=Spinner(this); spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,products)
        val qty=EditText(this).apply{hint="Quantity (kg / pieces)"; inputType=2}
        val waste=EditText(this).apply{hint="Wastage (optional)"; inputType=2}
        root.addView(spinner); root.addView(qty); root.addView(waste)
        root.addView(btn("Save Production"){ 
            prefs.edit().putString("lastProduction","${spinner.selectedItem}: ${qty.text} | Wastage: ${waste.text}").apply()
            Toast.makeText(this,"Production saved",Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("← Dashboard"){showDashboard()})
    }

    private fun sales() {
        base("Sales")
        val shop=EditText(this).apply{hint="Shop / Customer name"}
        val product=EditText(this).apply{hint="Product"}
        val quantity=EditText(this).apply{hint="Quantity"; inputType=2}
        val amount=EditText(this).apply{hint="Total amount ₹"; inputType=2}
        val payment=Spinner(this); payment.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Cash","UPI","Credit"))
        listOf(shop,product,quantity,amount).forEach{root.addView(it)}
        root.addView(payment)
        root.addView(btn("Save Sale"){
            prefs.edit().putString("lastSale","${shop.text} • ${product.text} • ₹${amount.text} • ${payment.selectedItem}").apply()
            Toast.makeText(this,"Sale saved",Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("← Dashboard"){showDashboard()})
    }

    private fun customers() {
        base("Customers")
        val name=EditText(this).apply{hint="Shop name"}
        val phone=EditText(this).apply{hint="Mobile number"; inputType=3}
        val outstanding=EditText(this).apply{hint="Outstanding ₹"; inputType=2}
        listOf(name,phone,outstanding).forEach{root.addView(it)}
        root.addView(btn("Save Customer"){
            prefs.edit().putString("customer","${name.text} | ${phone.text} | Outstanding ₹${outstanding.text}").apply()
            Toast.makeText(this,"Customer saved",Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("← Dashboard"){showDashboard()})
    }

    private fun stock() {
        base("Raw Material Stock")
        val items=arrayOf("Maida","Sugar","Yeast","Oil","Butter","Milk","Salt","Packaging")
        val item=Spinner(this); item.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,items)
        val qty=EditText(this).apply{hint="Quantity to add"; inputType=2}
        root.addView(item); root.addView(qty)
        root.addView(btn("Add Stock"){
            prefs.edit().putString("stock","${item.selectedItem}: ${qty.text}").apply()
            Toast.makeText(this,"Stock entry saved",Toast.LENGTH_SHORT).show()
        })
        root.addView(TextView(this).apply{text="\nFor V1, stock entries are stored locally on the phone. Recipe-based automatic consumption can be added in V2."; textSize=14f})
        root.addView(btn("← Dashboard"){showDashboard()})
    }

    private fun reports() {
        base("Reports")
        val p=prefs.getString("lastProduction","No production entry yet")
        val s=prefs.getString("lastSale","No sales entry yet")
        val c=prefs.getString("customer","No customer entry yet")
        val st=prefs.getString("stock","No stock entry yet")
        root.addView(TextView(this).apply{
            text="Latest saved entries:\n\n🏭 $p\n\n🧾 $s\n\n👥 $c\n\n📦 $st"
            textSize=16f
        })
        root.addView(btn("← Dashboard"){showDashboard()})
    }
}
